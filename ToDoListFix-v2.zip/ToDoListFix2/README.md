# ToDoListFix v2 — Полная версия

## Функционал
- ✅ Создание/удаление задач с приоритетом
- ✅ Подзадачи с раскрытием/скрытием (анимация)
- ✅ Комментарии к подзадачам
- ✅ Прикрепление картинок из галереи
- ✅ Запись и воспроизведение голосовых сообщений
- ✅ Форматирование текста (жирный, курсив, подчёркивание)
- ✅ Градиенты, скруглённые углы, анимации
- ✅ Счётчик выполненных задач

## Сборка в Codespaces

```bash
# 1. Установи Java 17
sudo apt-get update && sudo apt-get install -y openjdk-17-jdk-headless

# 2. Настрой Java
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export PATH=$JAVA_HOME/bin:$PATH

# 3. Скачай Android SDK
wget https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
unzip commandlinetools-linux-11076708_latest.zip -d cmdline-tools
mkdir -p ~/android-sdk/cmdline-tools
mv cmdline-tools/cmdline-tools ~/android-sdk/cmdline-tools/latest

# 4. Настрой SDK
export ANDROID_HOME=~/android-sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin

# 5. Установи платформу
yes | sdkmanager --licenses
sdkmanager "platforms;android-34" "build-tools;34.0.0"

# 6. Скачай Gradle 8.2
wget https://services.gradle.org/distributions/gradle-8.2-bin.zip
unzip gradle-8.2-bin.zip
export PATH=$(pwd)/gradle-8.2/bin:$PATH

# 7. Собери APK
chmod +x gradlew
gradle assembleDebug
```

APK будет в: `app/build/outputs/apk/debug/app-debug.apk`
