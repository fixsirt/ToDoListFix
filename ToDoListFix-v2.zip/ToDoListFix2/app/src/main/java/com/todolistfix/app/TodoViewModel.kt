package com.todolistfix.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TodoViewModel(app: Application) : AndroidViewModel(app) {
    private val db = AppDatabase.get(app)
    private val taskDao = db.taskDao()
    private val subtaskDao = db.subtaskDao()

    val tasks = taskDao.getAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addTask(title: String, priority: Int = 0) = viewModelScope.launch {
        taskDao.insert(Task(title = title, priority = priority))
    }
    fun toggleTask(task: Task) = viewModelScope.launch {
        taskDao.update(task.copy(isCompleted = !task.isCompleted))
    }
    fun deleteTask(task: Task) = viewModelScope.launch {
        taskDao.delete(task)
    }
    fun addSubtask(taskId: Long, title: String) = viewModelScope.launch {
        subtaskDao.insert(Subtask(taskId = taskId, title = title))
    }
    fun updateSubtask(sub: Subtask) = viewModelScope.launch {
        subtaskDao.update(sub)
    }
    fun toggleSubtask(sub: Subtask) = viewModelScope.launch {
        subtaskDao.update(sub.copy(isCompleted = !sub.isCompleted))
    }
    fun deleteSubtask(sub: Subtask) = viewModelScope.launch {
        subtaskDao.delete(sub)
    }
}
