package com.todolistfix.app

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val isCompleted: Boolean = false,
    val priority: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "subtasks",
    foreignKeys = [ForeignKey(Task::class, ["id"], ["taskId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("taskId")]
)
data class Subtask(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskId: Long,
    val title: String,
    val comment: String = "",
    val isCompleted: Boolean = false,
    val imagePath: String = "",
    val voicePath: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

data class TaskWithSubtasks(
    @Embedded val task: Task,
    @Relation(parentColumn = "id", entityColumn = "taskId")
    val subtasks: List<Subtask>
)

@Dao
interface TaskDao {
    @Transaction
    @Query("SELECT * FROM tasks ORDER BY priority DESC, createdAt DESC")
    fun getAll(): Flow<List<TaskWithSubtasks>>

    @Insert suspend fun insert(task: Task): Long
    @Update suspend fun update(task: Task)
    @Delete suspend fun delete(task: Task)
}

@Dao
interface SubtaskDao {
    @Insert suspend fun insert(s: Subtask): Long
    @Update suspend fun update(s: Subtask)
    @Delete suspend fun delete(s: Subtask)
}

@Database(entities = [Task::class, Subtask::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
    abstract fun subtaskDao(): SubtaskDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(ctx: Context) = INSTANCE ?: synchronized(this) {
            Room.databaseBuilder(ctx, AppDatabase::class.java, "todo.db").build().also { INSTANCE = it }
        }
    }
}
