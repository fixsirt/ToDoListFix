package com.todolistfix.app

import android.Manifest
import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.Spannable
import android.text.SpannableString
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var viewModel: TodoViewModel
    private lateinit var adapter: TaskAdapter
    private var pendingSubtaskId: Long = -1
    private val PICK_IMAGE_REQUEST = 1001
    private val AUDIO_PERMISSION_REQUEST = 1002

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        viewModel = ViewModelProvider(this)[TodoViewModel::class.java]
        adapter = TaskAdapter(viewModel,
            onPickImage = { subtaskId ->
                pendingSubtaskId = subtaskId
                val intent = Intent(Intent.ACTION_PICK).apply { type = "image/*" }
                startActivityForResult(intent, PICK_IMAGE_REQUEST)
            }
        )

        findViewById<RecyclerView>(R.id.recyclerView).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        lifecycleScope.launch {
            viewModel.tasks.collect {
                adapter.submitList(it)
                findViewById<TextView>(R.id.tvTaskCount).text =
                    "${it.size} задач • ${it.count { t -> t.task.isCompleted }} выполнено"
            }
        }

        findViewById<FloatingActionButton>(R.id.fab).setOnClickListener {
            showAddTaskDialog()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                val path = copyImageToInternal(uri)
                if (pendingSubtaskId != -1L) {
                    val current = adapter.getSubtaskById(pendingSubtaskId)
                    current?.let { viewModel.updateSubtask(it.copy(imagePath = path)) }
                }
            }
        }
    }

    private fun copyImageToInternal(uri: Uri): String {
        val dir = File(filesDir, "images").also { it.mkdirs() }
        val fileName = "img_${System.currentTimeMillis()}.jpg"
        val dest = File(dir, fileName)
        contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(dest).use { output -> input.copyTo(output) }
        }
        return dest.absolutePath
    }

    private fun showAddTaskDialog() {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialog_add_task)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.92).toInt(),
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        val etTitle = dialog.findViewById<EditText>(R.id.etTaskTitle)
        val btnNormal = dialog.findViewById<Button>(R.id.btnNormal)
        val btnHigh = dialog.findViewById<Button>(R.id.btnHigh)
        var priority = 0

        btnNormal.setOnClickListener {
            priority = 0
            btnNormal.backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF4C9EFF.toInt())
            btnHigh.backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF2A2F45.toInt())
        }
        btnHigh.setOnClickListener {
            priority = 1
            btnHigh.backgroundTintList = android.content.res.ColorStateList.valueOf(0xFFFF6B9D.toInt())
            btnNormal.backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF2A2F45.toInt())
        }

        dialog.findViewById<Button>(R.id.btnCancel).setOnClickListener { dialog.dismiss() }
        dialog.findViewById<Button>(R.id.btnConfirm).setOnClickListener {
            val title = etTitle.text.toString().trim()
            if (title.isNotEmpty()) {
                viewModel.addTask(title, priority)
                dialog.dismiss()
            }
        }
        dialog.show()
    }
}

class TaskAdapter(
    private val vm: TodoViewModel,
    private val onPickImage: (Long) -> Unit
) : RecyclerView.Adapter<TaskAdapter.VH>() {

    private var items: List<TaskWithSubtasks> = emptyList()
    private val expandedIds = mutableSetOf<Long>()
    private var mediaRecorder: MediaRecorder? = null
    private var mediaPlayer: MediaPlayer? = null
    private var recordingSubtaskId: Long = -1

    fun submitList(list: List<TaskWithSubtasks>) {
        items = list
        notifyDataSetChanged()
    }

    fun getSubtaskById(id: Long): Subtask? {
        return items.flatMap { it.subtasks }.find { it.id == id }
    }

    inner class VH(val view: View) : RecyclerView.ViewHolder(view)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_task, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        val task = item.task
        val v = holder.view

        val tvTitle = v.findViewById<TextView>(R.id.tvTitle)
        val check = v.findViewById<CheckBox>(R.id.checkTask)
        val btnDelete = v.findViewById<ImageButton>(R.id.btnDelete)
        val btnExpand = v.findViewById<ImageButton>(R.id.btnExpand)
        val subtasksContainer = v.findViewById<LinearLayout>(R.id.subtasksContainer)
        val btnShowAdd = v.findViewById<Button>(R.id.btnShowAddSubtask)
        val addContainer = v.findViewById<LinearLayout>(R.id.addSubtaskContainer)
        val etSubtask = v.findViewById<EditText>(R.id.etSubtask)
        val btnAddSub = v.findViewById<ImageButton>(R.id.btnAddSubtask)
        val tvCount = v.findViewById<TextView>(R.id.tvSubtaskCount)
        val priorityBar = v.findViewById<View>(R.id.priorityBar)

        val accentColor = if (task.priority == 1) 0xFFFF6B9D.toInt() else 0xFF4C9EFF.toInt()
        priorityBar.backgroundTintList = android.content.res.ColorStateList.valueOf(accentColor)

        tvTitle.text = task.title
        check.isChecked = task.isCompleted
        tvTitle.paintFlags = if (task.isCompleted)
            tvTitle.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        else tvTitle.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
        tvTitle.alpha = if (task.isCompleted) 0.5f else 1f

        if (item.subtasks.isNotEmpty()) {
            tvCount.visibility = View.VISIBLE
            tvCount.text = "${item.subtasks.count { it.isCompleted }}/${item.subtasks.size}"
        } else tvCount.visibility = View.GONE

        val isExpanded = expandedIds.contains(task.id)
        subtasksContainer.visibility = if (isExpanded) View.VISIBLE else View.GONE
        btnShowAdd.visibility = if (isExpanded) View.VISIBLE else View.GONE

        check.setOnCheckedChangeListener(null)
        check.setOnCheckedChangeListener { _, _ -> vm.toggleTask(task) }
        btnDelete.setOnClickListener { vm.deleteTask(task) }

        btnExpand.setOnClickListener {
            if (expandedIds.contains(task.id)) {
                expandedIds.remove(task.id)
                subtasksContainer.animate().alpha(0f).setDuration(250).withEndAction {
                    subtasksContainer.visibility = View.GONE
                    btnShowAdd.visibility = View.GONE
                }.start()
            } else {
                expandedIds.add(task.id)
                subtasksContainer.alpha = 0f
                subtasksContainer.visibility = View.VISIBLE
                btnShowAdd.visibility = View.VISIBLE
                subtasksContainer.animate().alpha(1f).setDuration(250).start()
            }
        }

        // Build subtasks
        subtasksContainer.removeAllViews()
        item.subtasks.forEach { sub ->
            val subView = LayoutInflater.from(v.context).inflate(R.layout.item_subtask, subtasksContainer, false)

            val tvSub = subView.findViewById<TextView>(R.id.tvSubtaskTitle)
            val checkSub = subView.findViewById<CheckBox>(R.id.checkSubtask)
            val btnDelSub = subView.findViewById<ImageButton>(R.id.btnDeleteSubtask)
            val etComment = subView.findViewById<EditText>(R.id.etComment)
            val tvComment = subView.findViewById<TextView>(R.id.tvComment)
            val imgPreview = subView.findViewById<ImageView>(R.id.imgPreview)
            val btnPickImage = subView.findViewById<ImageButton>(R.id.btnPickImage)
            val btnRecord = subView.findViewById<ImageButton>(R.id.btnRecord)
            val btnPlayVoice = subView.findViewById<ImageButton>(R.id.btnPlayVoice)
            val btnBold = subView.findViewById<Button>(R.id.btnBold)
            val btnItalic = subView.findViewById<Button>(R.id.btnItalic)
            val btnUnderline = subView.findViewById<Button>(R.id.btnUnderline)
            val formatBar = subView.findViewById<LinearLayout>(R.id.formatBar)
            val detailsContainer = subView.findViewById<LinearLayout>(R.id.detailsContainer)
            val btnToggleDetails = subView.findViewById<ImageButton>(R.id.btnToggleDetails)

            tvSub.text = sub.title
            checkSub.isChecked = sub.isCompleted
            tvSub.paintFlags = if (sub.isCompleted)
                tvSub.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            else tvSub.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
            tvSub.alpha = if (sub.isCompleted) 0.5f else 1f

            // Comment
            if (sub.comment.isNotEmpty()) {
                tvComment.visibility = View.VISIBLE
                tvComment.text = sub.comment
            } else tvComment.visibility = View.GONE

            etComment.setText(sub.comment)
            etComment.setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus) {
                    val newComment = etComment.text.toString()
                    if (newComment != sub.comment) {
                        vm.updateSubtask(sub.copy(comment = newComment))
                    }
                }
            }

            // Image
            if (sub.imagePath.isNotEmpty()) {
                val file = File(sub.imagePath)
                if (file.exists()) {
                    imgPreview.visibility = View.VISIBLE
                    imgPreview.setImageBitmap(BitmapFactory.decodeFile(sub.imagePath))
                }
            } else imgPreview.visibility = View.GONE

            btnPickImage.setOnClickListener { onPickImage(sub.id) }

            // Voice
            btnPlayVoice.visibility = if (sub.voicePath.isNotEmpty()) View.VISIBLE else View.GONE
            btnRecord.setOnClickListener {
                val ctx = v.context
                if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(ctx as Activity, arrayOf(Manifest.permission.RECORD_AUDIO), 1002)
                    return@setOnClickListener
                }
                if (recordingSubtaskId == sub.id) {
                    // Stop recording
                    mediaRecorder?.apply { stop(); release() }
                    mediaRecorder = null
                    recordingSubtaskId = -1
                    btnRecord.setImageResource(android.R.drawable.ic_btn_speak_now)
                    vm.updateSubtask(sub.copy(voicePath = getVoicePath(sub.id)))
                    btnPlayVoice.visibility = View.VISIBLE
                } else {
                    // Start recording
                    recordingSubtaskId = sub.id
                    val path = getVoicePath(sub.id)
                    val dir = File(ctx.filesDir, "voice").also { it.mkdirs() }
                    mediaRecorder = MediaRecorder().apply {
                        setAudioSource(MediaRecorder.AudioSource.MIC)
                        setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP)
                        setOutputFile(File(dir, "voice_${sub.id}.3gp").absolutePath)
                        setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
                        prepare()
                        start()
                    }
                    btnRecord.setImageResource(android.R.drawable.ic_media_pause)
                }
            }

            btnPlayVoice.setOnClickListener {
                if (sub.voicePath.isNotEmpty()) {
                    mediaPlayer?.release()
                    mediaPlayer = MediaPlayer().apply {
                        setDataSource(sub.voicePath)
                        prepare()
                        start()
                    }
                }
            }

            // Format bar
            tvSub.setOnClickListener {
                formatBar.visibility = if (formatBar.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }

            btnBold.setOnClickListener {
                val sel = etComment.text
                val s = etComment.selectionStart.coerceAtLeast(0)
                val e = etComment.selectionEnd.coerceAtLeast(s)
                if (s < e) sel.setSpan(StyleSpan(android.graphics.Typeface.BOLD), s, e, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            btnItalic.setOnClickListener {
                val sel = etComment.text
                val s = etComment.selectionStart.coerceAtLeast(0)
                val e = etComment.selectionEnd.coerceAtLeast(s)
                if (s < e) sel.setSpan(StyleSpan(android.graphics.Typeface.ITALIC), s, e, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            btnUnderline.setOnClickListener {
                val sel = etComment.text
                val s = etComment.selectionStart.coerceAtLeast(0)
                val e = etComment.selectionEnd.coerceAtLeast(s)
                if (s < e) sel.setSpan(UnderlineSpan(), s, e, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            }

            // Toggle details
            btnToggleDetails.setOnClickListener {
                if (detailsContainer.visibility == View.VISIBLE) {
                    detailsContainer.animate().alpha(0f).setDuration(200).withEndAction {
                        detailsContainer.visibility = View.GONE
                    }.start()
                } else {
                    detailsContainer.alpha = 0f
                    detailsContainer.visibility = View.VISIBLE
                    detailsContainer.animate().alpha(1f).setDuration(200).start()
                }
            }

            checkSub.setOnCheckedChangeListener(null)
            checkSub.setOnCheckedChangeListener { _, _ -> vm.toggleSubtask(sub) }
            btnDelSub.setOnClickListener { vm.deleteSubtask(sub) }

            subtasksContainer.addView(subView)
        }

        btnShowAdd.setOnClickListener {
            addContainer.visibility = if (addContainer.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        btnAddSub.setOnClickListener {
            val title = etSubtask.text.toString().trim()
            if (title.isNotEmpty()) {
                vm.addSubtask(task.id, title)
                etSubtask.setText("")
                addContainer.visibility = View.GONE
            }
        }
    }

    private fun getVoicePath(subtaskId: Long): String = ""
}
