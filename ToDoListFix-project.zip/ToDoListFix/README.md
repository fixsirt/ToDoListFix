# ToDoListFix — Android App

## Красивый тёмный TODO с подзадачами для Android 14

### Технологии
- **Kotlin** + **Jetpack Compose** (декларативный UI)
- **Room Database** (локальное хранилище задач)
- **Material3** с кастомной тёмной темой
- Анимации: `AnimatedVisibility`, `animateFloatAsState`, градиенты, стеклянный эффект

### Функционал
✅ Создание задач с приоритетом (Обычный / Высокий)  
✅ Отметка задачи выполненной (с анимацией fade + зачёркивание)  
✅ Удаление задач  
✅ Подзадачи для каждой задачи (expand/collapse с анимацией)  
✅ Отметка/удаление подзадач  
✅ Счётчик выполненных подзадач  
✅ Данные сохраняются локально в Room DB

### Дизайн
- Тёмный фон `#0A0F1E` с градиентными "блобами"
- Стеклянные карточки с gradient border
- Цветовые акценты: синий, фиолетовый, розовый, зелёный
- Скруглённые углы 20dp
- Edge-to-edge (прозрачный статус-бар)

---

## Как собрать APK

### Шаг 1: Установите Android Studio
Скачайте с: https://developer.android.com/studio

### Шаг 2: Откройте проект
File → Open → выберите папку `ToDoListFix`

### Шаг 3: Синхронизируйте Gradle
Android Studio сделает это автоматически. Подождите пока загрузятся зависимости.

### Шаг 4: Соберите APK
- Меню: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
- APK появится в: `app/build/outputs/apk/debug/app-debug.apk`

### Шаг 5: Установите на устройство
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```
Или перенесите APK файл на телефон и установите вручную (включите "Установка из неизвестных источников").

---

## Структура проекта
```
ToDoListFix/
├── app/src/main/
│   ├── AndroidManifest.xml
│   └── java/com/todolistfix/app/
│       ├── MainActivity.kt          ← точка входа
│       ├── data/Database.kt         ← Room DB, DAO, Entity
│       ├── viewmodel/TodoViewModel  ← бизнес-логика
│       └── ui/TodoScreen.kt         ← весь Compose UI
```
