package com.todolistfix.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.todolistfix.app.data.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TodoViewModel(app: Application) : AndroidViewModel(app) {

    private val db = AppDatabase.getInstance(app)
    private val taskDao = db.taskDao()
    private val subtaskDao = db.subtaskDao()

    val tasksWithSubtasks = taskDao.getAllTasksWithSubtasks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addTask(title: String, priority: Int = 0) = viewModelScope.launch {
        taskDao.insertTask(Task(title = title, priority = priority))
    }

    fun toggleTask(task: Task) = viewModelScope.launch {
        taskDao.updateTask(task.copy(isCompleted = !task.isCompleted))
    }

    fun deleteTask(task: Task) = viewModelScope.launch {
        taskDao.deleteTask(task)
    }

    fun addSubtask(taskId: Long, title: String) = viewModelScope.launch {
        subtaskDao.insertSubtask(Subtask(taskId = taskId, title = title))
    }

    fun toggleSubtask(subtask: Subtask) = viewModelScope.launch {
        subtaskDao.updateSubtask(subtask.copy(isCompleted = !subtask.isCompleted))
    }

    fun deleteSubtask(subtask: Subtask) = viewModelScope.launch {
        subtaskDao.deleteSubtask(subtask)
    }
}
