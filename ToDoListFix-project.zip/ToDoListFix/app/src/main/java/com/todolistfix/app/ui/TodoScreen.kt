package com.todolistfix.app.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.todolistfix.app.data.*
import com.todolistfix.app.viewmodel.TodoViewModel

// ─── Color Palette ────────────────────────────────────────────────────────────

val BgDeep = Color(0xFF0A0F1E)
val BgCard = Color(0xFF121929)
val BgCardAlt = Color(0xFF161E30)
val AccentBlue = Color(0xFF4C9EFF)
val AccentViolet = Color(0xFF9B72FF)
val AccentGreen = Color(0xFF48F0A0)
val AccentPink = Color(0xFFFF6B9D)
val TextPrimary = Color(0xFFF0F4FF)
val TextSecondary = Color(0xFF8899BB)
val GlassBorder = Color(0x33FFFFFF)

// ─── Theme ────────────────────────────────────────────────────────────────────

val AppColorScheme = darkColorScheme(
    background = BgDeep,
    surface = BgCard,
    primary = AccentBlue,
    secondary = AccentViolet,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
)

// ─── Main Screen ──────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TodoScreen(viewModel: TodoViewModel) {
    val tasks by viewModel.tasksWithSubtasks.collectAsStateWithLifecycle()
    var showAddDialog by remember { mutableStateOf(false) }
    var expandedTaskId by remember { mutableStateOf<Long?>(null) }

    MaterialTheme(colorScheme = AppColorScheme) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(BgDeep)
        ) {
            // Background gradient blobs
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(AccentBlue.copy(alpha = 0.12f), Color.Transparent),
                        center = Offset(size.width * 0.1f, size.height * 0.15f),
                        radius = size.width * 0.5f
                    ),
                    radius = size.width * 0.5f,
                    center = Offset(size.width * 0.1f, size.height * 0.15f)
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(AccentViolet.copy(alpha = 0.10f), Color.Transparent),
                        center = Offset(size.width * 0.9f, size.height * 0.8f),
                        radius = size.width * 0.6f
                    ),
                    radius = size.width * 0.6f,
                    center = Offset(size.width * 0.9f, size.height * 0.8f)
                )
            }

            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                TopBar(taskCount = tasks.size)

                // Task List
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(tasks, key = { it.task.id }) { taskWithSubs ->
                        AnimatedTaskCard(
                            taskWithSubtasks = taskWithSubs,
                            isExpanded = expandedTaskId == taskWithSubs.task.id,
                            onToggleExpand = {
                                expandedTaskId = if (expandedTaskId == taskWithSubs.task.id)
                                    null else taskWithSubs.task.id
                            },
                            onToggleTask = { viewModel.toggleTask(taskWithSubs.task) },
                            onDeleteTask = { viewModel.deleteTask(taskWithSubs.task) },
                            onAddSubtask = { title -> viewModel.addSubtask(taskWithSubs.task.id, title) },
                            onToggleSubtask = { sub -> viewModel.toggleSubtask(sub) },
                            onDeleteSubtask = { sub -> viewModel.deleteSubtask(sub) }
                        )
                    }
                    item { Spacer(Modifier.height(80.dp)) }
                }
            }

            // FAB
            FloatingActionButton(
                onClick = { showAddDialog = true },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(24.dp)
                    .size(60.dp),
                shape = CircleShape,
                containerColor = Color.Transparent,
                contentColor = TextPrimary
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(listOf(AccentBlue, AccentViolet)),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Task", tint = Color.White)
                }
            }
        }

        if (showAddDialog) {
            AddTaskDialog(
                onDismiss = { showAddDialog = false },
                onAdd = { title, priority ->
                    viewModel.addTask(title, priority)
                    showAddDialog = false
                }
            )
        }
    }
}

// ─── Top Bar ─────────────────────────────────────────────────────────────────

@Composable
fun TopBar(taskCount: Int) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 20.dp)
    ) {
        Column {
            Text(
                text = "ToDoListFix",
                color = TextPrimary,
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (-1).sp
            )
            Text(
                text = "$taskCount задач",
                color = TextSecondary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

// ─── Task Card ────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnimatedTaskCard(
    taskWithSubtasks: TaskWithSubtasks,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onToggleTask: () -> Unit,
    onDeleteTask: () -> Unit,
    onAddSubtask: (String) -> Unit,
    onToggleSubtask: (Subtask) -> Unit,
    onDeleteSubtask: (Subtask) -> Unit
) {
    val task = taskWithSubtasks.task
    val subtasks = taskWithSubtasks.subtasks
    var showSubtaskField by remember { mutableStateOf(false) }
    var subtaskText by remember { mutableStateOf("") }

    val accentColor = if (task.priority == 1) AccentPink else AccentBlue
    val completedAlpha by animateFloatAsState(if (task.isCompleted) 0.45f else 1f)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(completedAlpha),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = BgCard,
                    shape = RoundedCornerShape(20.dp)
                )
                .border(
                    width = 1.dp,
                    brush = Brush.linearGradient(
                        listOf(GlassBorder, Color.Transparent, GlassBorder)
                    ),
                    shape = RoundedCornerShape(20.dp)
                )
        ) {
            // Left accent bar
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(50.dp)
                    .align(Alignment.CenterStart)
                    .padding(start = 12.dp)
                    .background(
                        Brush.verticalGradient(listOf(accentColor, accentColor.copy(alpha = 0.3f))),
                        RoundedCornerShape(2.dp)
                    )
            )

            Column(modifier = Modifier.padding(start = 24.dp, end = 12.dp, top = 14.dp, bottom = 14.dp)) {
                // Main row
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Checkbox
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .border(2.dp, accentColor, CircleShape)
                            .background(
                                if (task.isCompleted)
                                    Brush.radialGradient(listOf(accentColor, accentColor.copy(0.5f)))
                                else
                                    Brush.radialGradient(listOf(Color.Transparent, Color.Transparent)),
                                CircleShape
                            )
                            .clickable { onToggleTask() },
                        contentAlignment = Alignment.Center
                    ) {
                        AnimatedVisibility(visible = task.isCompleted) {
                            Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(14.dp))
                        }
                    }

                    Spacer(Modifier.width(12.dp))

                    // Title
                    Text(
                        text = task.title,
                        color = if (task.isCompleted) TextSecondary else TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        textDecoration = if (task.isCompleted) TextDecoration.LineThrough else null,
                        modifier = Modifier.weight(1f)
                    )

                    // Subtask count badge
                    if (subtasks.isNotEmpty()) {
                        Box(
                            modifier = Modifier
                                .background(accentColor.copy(0.18f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "${subtasks.count { it.isCompleted }}/${subtasks.size}",
                                color = accentColor,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(Modifier.width(6.dp))
                    }

                    // Expand button
                    IconButton(onClick = onToggleExpand, modifier = Modifier.size(32.dp)) {
                        val rotation by animateFloatAsState(if (isExpanded) 180f else 0f)
                        Icon(
                            Icons.Default.KeyboardArrowDown, null,
                            tint = TextSecondary,
                            modifier = Modifier.rotate(rotation)
                        )
                    }

                    // Delete button
                    IconButton(onClick = onDeleteTask, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Delete, null, tint = TextSecondary.copy(0.6f), modifier = Modifier.size(18.dp))
                    }
                }

                // Expanded subtasks
                AnimatedVisibility(
                    visible = isExpanded,
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut()
                ) {
                    Column {
                        if (subtasks.isNotEmpty()) {
                            Spacer(Modifier.height(12.dp))
                            HorizontalDivider(color = GlassBorder, thickness = 0.5.dp)
                            Spacer(Modifier.height(8.dp))
                        }

                        subtasks.forEach { subtask ->
                            SubtaskRow(
                                subtask = subtask,
                                onToggle = { onToggleSubtask(subtask) },
                                onDelete = { onDeleteSubtask(subtask) }
                            )
                            Spacer(Modifier.height(4.dp))
                        }

                        // Add subtask field
                        if (showSubtaskField) {
                            Spacer(Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                TextField(
                                    value = subtaskText,
                                    onValueChange = { subtaskText = it },
                                    placeholder = { Text("Подзадача...", color = TextSecondary, fontSize = 14.sp) },
                                    modifier = Modifier.weight(1f),
                                    colors = TextFieldDefaults.colors(
                                        focusedContainerColor = BgCardAlt,
                                        unfocusedContainerColor = BgCardAlt,
                                        focusedIndicatorColor = Color.Transparent,
                                        unfocusedIndicatorColor = Color.Transparent,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary,
                                        cursorColor = AccentBlue
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    singleLine = true,
                                    textStyle = LocalTextStyle.current.copy(fontSize = 14.sp)
                                )
                                Spacer(Modifier.width(6.dp))
                                IconButton(
                                    onClick = {
                                        if (subtaskText.isNotBlank()) {
                                            onAddSubtask(subtaskText.trim())
                                            subtaskText = ""
                                            showSubtaskField = false
                                        }
                                    }
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .background(
                                                Brush.linearGradient(listOf(AccentBlue, AccentViolet)),
                                                CircleShape
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }

                        Spacer(Modifier.height(8.dp))
                        // Add subtask button
                        TextButton(
                            onClick = { showSubtaskField = !showSubtaskField },
                            modifier = Modifier.height(32.dp)
                        ) {
                            Icon(
                                if (showSubtaskField) Icons.Default.Remove else Icons.Default.Add,
                                null,
                                tint = accentColor,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text(
                                if (showSubtaskField) "Отмена" else "Добавить подзадачу",
                                color = accentColor,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }
    }
}

// ─── Subtask Row ──────────────────────────────────────────────────────────────

@Composable
fun SubtaskRow(subtask: Subtask, onToggle: () -> Unit, onDelete: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .background(BgCardAlt, RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(18.dp)
                .border(1.5.dp, AccentGreen.copy(0.7f), RoundedCornerShape(4.dp))
                .background(
                    if (subtask.isCompleted) AccentGreen.copy(0.3f) else Color.Transparent,
                    RoundedCornerShape(4.dp)
                )
                .clickable { onToggle() },
            contentAlignment = Alignment.Center
        ) {
            if (subtask.isCompleted) {
                Icon(Icons.Default.Check, null, tint = AccentGreen, modifier = Modifier.size(11.dp))
            }
        }
        Spacer(Modifier.width(10.dp))
        Text(
            text = subtask.title,
            color = if (subtask.isCompleted) TextSecondary else TextPrimary.copy(0.85f),
            fontSize = 14.sp,
            textDecoration = if (subtask.isCompleted) TextDecoration.LineThrough else null,
            modifier = Modifier.weight(1f)
        )
        IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
            Icon(Icons.Default.Close, null, tint = TextSecondary.copy(0.5f), modifier = Modifier.size(14.dp))
        }
    }
}

// ─── Add Task Dialog ──────────────────────────────────────────────────────────

@Composable
fun AddTaskDialog(onDismiss: () -> Unit, onAdd: (String, Int) -> Unit) {
    var text by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf(0) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = BgCard,
        shape = RoundedCornerShape(24.dp),
        title = {
            Text("Новая задача", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        },
        text = {
            Column {
                TextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("Название задачи...", color = TextSecondary) },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = BgCardAlt,
                        unfocusedContainerColor = BgCardAlt,
                        focusedIndicatorColor = AccentBlue,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = AccentBlue
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(16.dp))
                Text("Приоритет", color = TextSecondary, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PriorityChip("Обычный", 0, priority == 0, AccentBlue) { priority = 0 }
                    PriorityChip("Высокий", 1, priority == 1, AccentPink) { priority = 1 }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { if (text.isNotBlank()) onAdd(text.trim(), priority) },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                contentPadding = PaddingValues(0.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .background(
                            Brush.linearGradient(listOf(AccentBlue, AccentViolet)),
                            RoundedCornerShape(12.dp)
                        )
                        .padding(horizontal = 24.dp, vertical = 10.dp)
                ) {
                    Text("Добавить", color = Color.White, fontWeight = FontWeight.SemiBold)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена", color = TextSecondary)
            }
        }
    )
}

@Composable
fun PriorityChip(label: String, value: Int, selected: Boolean, color: Color, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(
                if (selected) color.copy(0.2f) else BgCardAlt,
                RoundedCornerShape(10.dp)
            )
            .border(1.dp, if (selected) color else Color.Transparent, RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(label, color = if (selected) color else TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}
